import React from "react";
import "./auth.css";

const Register = () => {
  return <div>Register</div>;
};

export default Register;
